#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "[X] 请先安装 Node.js 18+ LTS：https://nodejs.org/zh-cn/download/"
  read -r -p "按回车退出" _
  exit 1
fi
echo "[1/3] 安装依赖..."
if [ ! -d node_modules ]; then npm install || { echo "依赖安装失败"; read -r _; exit 1; }; fi
echo "[2/3] 构建前端（如已存在会跳过）..."
if [ ! -d dist ]; then npx vite build || { echo "构建失败"; read -r _; exit 1; }; fi
echo "[3/3] 启动服务..."
open "http://localhost:3001"
npm start
read -r -p "按回车退出" _
